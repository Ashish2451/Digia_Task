import React from "react";

function Card({ card, activeTab }) {
  return (
    <div className={`card ${activeTab.toLowerCase().replace(" ", "-")}`}>
      <div className="card-details">
        <div className="card-name">{card.name}</div>
        <div className="card-budget">{card.budget_name}</div>
        <div className="card-amount">{card.amount}</div>
        <div className="card-frequency">{card.frequency}</div>
        {card.card_type === "burner" ? (
          <div className="card-expiry">{`Expiry: ${card.expiry}`}</div>
        ) : (
          <div className="card-limit">{`Limit: ${card.limit}`}</div>
        )}
        <div className="card-spent">{`Spent: ${card.spent}`}</div>
        <div className="card-balance">{`Balance: ${card.balance}`}</div>
      </div>
      <div className="card-icon">
        <i className="fas fa-credit-card"></i> {/* Card Icon */}
      </div>
      <div className="card-type">
        <span>{card.card_type}</span>
      </div>
    </div>
  );
}

export default Card;
