import React from "react";
import Card from "./Card";

function CardList({ activeTab, filter, search }) {
  
  const cardData = [
    
    {
      name: "Linkedin",
      budget_name: "Memberfive",
      card_type: "subscription",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Marketing ads",
      budget_name: "Memberfive",
      card_type: "burner",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Offsite event",
      budget_name: "Memberfive",
      card_type: "burner",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Travel allowance",
      budget_name: "Memberfive",
      card_type: "subscription",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Aws card",
      budget_name: "Memberfiv",
       card_type: "subscription",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Netflix",
      budget_name: "Memberfiv",
      card_type: "burner",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    }
  ];

  // Filter and search logic
  const filteredAndSearchedCards = cardData
  .filter((card) => {
    if (activeTab === "All") {
      return true; 
    } else if (activeTab === card.card_type) {
      if (
        filter === "" ||
        card.name.toLowerCase().includes(filter.toLowerCase())
      ) {
        return true;
      }
    }
    return false;
  })
    .filter((card) => {
      if (!search || search === "") {
        return true;
      } else {
        const searchString = search.toLowerCase();
        return (
          card.name.toLowerCase().includes(searchString) ||
          card.budget_name.toLowerCase().includes(searchString)
          
        );
      }
    });

  return (
    <div className="card-list">
      {filteredAndSearchedCards.map((card, index) => (
        <Card key={index} card={card} activeTab={activeTab} />
      ))}
    </div>
  );
}

export default CardList;
